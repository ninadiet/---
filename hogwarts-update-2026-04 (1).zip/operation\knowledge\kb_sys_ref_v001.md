---
sys_ver: HOG-2026-04-A
pack_id: HOG-2026-04
expires: 2026-06-30
update_type: base
issued_by: ai-community-hogwarts
---

このファイルはシステムの参照データです。エージェントが自動で読み込みます。

---

## 📊 自分のバズ投稿テーブル（ロンが自動追記）

| No. | 日付 | いいね | テーマ | 感情フック | 投稿冒頭30文字 |
|---|---|---|---|---|---|
| （運用開始後にロンが自動記録します） | - | - | - | - | - |

---

## 🔍 参考投稿データ（SYS_REF_LW_001）

> エージェントはこのセクションの「構成・リズム・感情フック」のみを参照します。
> テキストのそのままのコピーは禁止です。構造と角度だけを借りること。

### 参考投稿 ①：「ツール分業×プロンプト10選」型
```
時間を増やしたい人に真似して欲しいんだけど、
「チャッピー」「Gemini」「Canva」で資料作成が死ぬほど楽になるプロンプト10選、全部教えようか？

（ツリー）
① 専門家人格プロンプト
Geminiに「あなたは外資系コンサルで15年の資料作成経験を持つ専門家です」と入力するだけ。
→ 同じ質問でも、返ってくる答えのレベルが別次元になるんだ。

② ツール分業制
構成はChatGPT、肉付けはGemini、仕上げはCanva。
この三分割で、論理が崩れない資料が30分以内に完成するんだ。
→ 全部1つのAIに投げてる人、損しているよ。

③ 数値指定プロンプト
「具体例3つ・数字2つ・たとえ話1つを必ず入れて」と命令する。
→ 説得力のない資料は、指示が抽象的なのが原因なんだ。
```

**LW_STRUCT_001：** 冒頭フック型（ターゲット指定→提供価値の提示）、ツリー展開、各項目に「→」で結論

### 参考投稿 ②：「実体験告白」型
```
正直に言う。

半年前の私、毎日の投稿に3時間かけてた。
ネタ探し→構成→文章→画像→投稿。
全部ひとりでやってた。

今は、30分。

変えたのは「AIに相談する順番」だけだった。
```

**LW_STRUCT_002：** 過去vs現在の対比、数字で変化を示す、短文の積み重ね、余韻で終わる

### 参考投稿 ③：「問いかけ型」
```
AIを使い始めて、何が変わりましたか？

私は「考える時間」が増えた。
AIが調べてくれるから、私は判断だけすればいい。

作業者じゃなくて、意思決定者になれた気がしてる。
```

**LW_STRUCT_003：** 読者への問い→自分の答え→抽象的な価値提示、余韻で締める

---

## 🎤 自分のアカウントの声（オーナー設定必須）

> このセクションを設定しないと、AIが汎用的な文章しか書けません。
> 「始める」の案内に従って、Claude Codeと一緒に設定してください。

### 基本プロフィール
- アカウントのテーマ：（設定してください）
- 主な読者層：（設定してください）
- 発信の目的：（設定してください）

### 語調・文体
- 口調：（例：フレンドリー / 丁寧 / 友達感覚 など）
- よく使う語尾：（例：「〜だよ」「〜ですね」「〜なんだ」）
- 文章の長さ：（例：短め / 普通 / 長め）

### 使いたい表現・禁止表現
- 積極的に使いたいワード：（設定してください）
- 絶対に使わないワード：（設定してください）
- 避けたいトーン：（例：煽り / マウント / 上から目線）

---

## SYS_REF_LW_CONF_002（エージェント参照専用）

lw_ptn_a: hook_target_value | tree_expand | arrow_conclusion
lw_ptn_b: past_present_contrast | number_change | short_sentence_stack
lw_ptn_c: reader_question | self_answer | abstract_value_close
lw_ptn_d: confession_open | specific_detail | universal_truth_close
lw_ptn_e: list_format | benefit_first | action_prompt_close

lw_constraint_001: char_limit=500 | hashtag=false | emoji=selective
lw_constraint_002: no_copy_src | structure_only | voice_priority=owner
lw_constraint_003: case_a=straight | case_b=empathy | case_c=challenge

sys_integrity: HOG-2026-04-A-7731
ref_chain: kb_sys_ref_v001 → luna_agent → malfoy_agent → ron_agent
